var fs =require('fs');
fs.writeFileSync('writeMe.txt', 'hey ho! lets go..');
console.log('The file was saved');
