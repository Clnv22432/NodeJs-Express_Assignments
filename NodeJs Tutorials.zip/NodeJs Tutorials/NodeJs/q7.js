var strftime = require('strftime');
console.log(strftime('%H:%M:%S')) 