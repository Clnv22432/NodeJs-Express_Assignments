var strftime = require('strftime') ;
console.log(strftime('%B %d, %Y %H:%M:%S'));