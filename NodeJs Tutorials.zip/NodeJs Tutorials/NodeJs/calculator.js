function sum(a, b){
    return a+b;
}

function mul(a,b){
    return a*b;
}

module.exports.sum = sum;
module.exports.mul = mul;